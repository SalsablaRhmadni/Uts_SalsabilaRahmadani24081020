package com.example.perhitungangajikaryawan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TentangAplikasiSalsabila extends AppCompatActivity {
    Button btnKembaliTentang;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_aplikasi_salsabila);

        btnKembaliTentang = findViewById(R.id.btnKembaliTentang);

        btnKembaliTentang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}