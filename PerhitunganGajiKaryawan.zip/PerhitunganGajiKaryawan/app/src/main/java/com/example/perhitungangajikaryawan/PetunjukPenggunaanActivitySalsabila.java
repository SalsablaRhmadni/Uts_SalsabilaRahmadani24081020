package com.example.perhitungangajikaryawan;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class PetunjukPenggunaanActivitySalsabila extends AppCompatActivity {
    Button btnKembaliPetunjuk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petunjuk_penggunaan_salsabila);

        btnKembaliPetunjuk = findViewById(R.id.btnKembaliPetunjuk);
        btnKembaliPetunjuk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}