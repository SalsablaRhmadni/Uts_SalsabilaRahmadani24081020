package com.example.perhitungangajikaryawan;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GajiActivitySalsabila extends AppCompatActivity {

    EditText etNik, etNama, etGajiPokok, etTunjanganJabatan, etHariKerja;
    EditText etTunjanganMakan, etTunjanganTransport, etGajiKotor, etGajiBersih;
    Button btnHitung, btnKembaliGaji;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gaji_salsabila);

        etNik = findViewById(R.id.etNik);
        etNama = findViewById(R.id.etNama);
        etGajiPokok = findViewById(R.id.etGajiPokok);
        etTunjanganJabatan = findViewById(R.id.etTunjanganJabatan);
        etHariKerja = findViewById(R.id.etHariKerja);

        etTunjanganMakan = findViewById(R.id.etTunjanganMakan);
        etTunjanganTransport = findViewById(R.id.etTunjanganTransport);
        etGajiKotor = findViewById(R.id.etGajiKotor);
        etGajiBersih = findViewById(R.id.etGajiBersih);


        btnHitung = findViewById(R.id.btnHitung);
        btnKembaliGaji = findViewById(R.id.btnKembaliGaji);


        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hitungGaji();
            }
        });


        btnKembaliGaji.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void hitungGaji() {
        // Validasi agar inputan tidak kosong
        if (etGajiPokok.getText().toString().isEmpty() ||
                etTunjanganJabatan.getText().toString().isEmpty() ||
                etHariKerja.getText().toString().isEmpty()) {

            Toast.makeText(this, "Harap isi Gaji Pokok, Tunjangan Jabatan, dan Hari Kerja!", Toast.LENGTH_SHORT).show();
            return;
        }


        double gajiPokok = Double.parseDouble(etGajiPokok.getText().toString());
        double tunjJabatan = Double.parseDouble(etTunjanganJabatan.getText().toString());
        int hariKerja = Integer.parseInt(etHariKerja.getText().toString());


        double tunjMakan = hariKerja * 10000;

        double tunjTransport = hariKerja * 5000;

        double gajiKotor = gajiPokok + tunjJabatan + tunjMakan + tunjTransport;

        double pajak = 0.10 * gajiKotor;
        double gajiBersih = gajiKotor - pajak;

        etTunjanganMakan.setText(String.valueOf((long) tunjMakan));
        etTunjanganTransport.setText(String.valueOf((long) tunjTransport));
        etGajiKotor.setText(String.valueOf((long) gajiKotor));
        etGajiBersih.setText(String.valueOf((long) gajiBersih));
    }
}